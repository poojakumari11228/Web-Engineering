<?php
# To return the following components of any url stored in a variable such as:
$url = 'http://www.sw.muet.edu.pk/faculty/cvs/sample.pdf';

print_r(parse_url($url));

?>