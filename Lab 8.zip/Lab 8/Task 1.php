<?php 
# To redirect a user to a different web page (for example: http://sw.muet.edu.pk)
header('Location:http://sw.muet.edu.pk');
?>