<?php
# To display the following strings:

echo '<ul>';
echo '<li>'. 'Tomorrow I’ll learn something new' . '</li>';
echo '<li>'. 'This is a bad command: del c:\*.*\$.' . '</li>';
echo '</ul>';
?>